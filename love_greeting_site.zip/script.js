const hearts = document.querySelectorAll('.heart');
const result = document.querySelector('.result');
const letter = document.querySelector('.love-letter');
const bgm = document.getElementById('bgm');

bgm.volume = 0.2;

hearts.forEach(heart => {
  heart.addEventListener('click', () => {
    if (heart.dataset.correct === "true") {
      result.textContent = "🎉 Яг зөв! Миний зүрх чинийх боллоо!";
      setTimeout(() => {
        document.querySelector('.game-screen').style.display = 'none';
        letter.style.display = 'block';
      }, 1500);
    } else {
      result.textContent = "😢 Арай биш ээ... дахин оролдоорой!";
    }
  });
});
